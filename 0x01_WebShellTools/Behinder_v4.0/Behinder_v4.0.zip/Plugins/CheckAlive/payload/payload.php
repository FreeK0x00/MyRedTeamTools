<?

function execute($taskID, $params)
{
    $aliveList = array();
    @session_start();
    $_SESSION[$taskID]["running"] = "true";
    $_SESSION[$taskID]["result"] = json_encode($aliveList);
    @session_write_close();

    $ipList = explode(",",trim($params["ipList"],","));
    $ips=array();
    foreach($ipList as $ip)
    {
        if (strpos($ip,"-")>0)
        {
            $start=ip2long(explode("-",$ip)[0]);
            $stop=ip2long(explode("-",$ip)[1]);
            for(;$start<=$stop;$start++)
            {
                array_push($ips,long2ip($start));
            }
        }
        else
        {
            array_push($ips,$ip);
        }
    }

    foreach($ips as $ip)
    {
        $running=$_SESSION[$taskID]["running"];
        if ($running==="false")
        {
            return;
        }

        if (reachable($ip))
        {
            array_push($aliveList,$ip);
            @session_start();
            $_SESSION[$taskID]["result"] = str_replace(array("[","]","\""),"",json_encode($aliveList));
            @session_write_close();
            
        }
    }
    @session_start();
    $_SESSION[$taskID]["running"] = "false";
    $_SESSION[$taskID]["result"] = json_encode($aliveList);
    @session_write_close();
    
}
function reachable($address){
	if(strtolower(PHP_OS)=='winnt'){
		$command = "ping -n 1 $address";
		exec($command, $output, $status);
	}else{
		$command = "ping -c 1 $address";
		exec($command, $output, $status);
	}
	if($status === 0){
		return true;
	}else{
		return false;
	}
}