<?php
    // $str1 = '6jisdf^ getBasicsInfo fud2ks28';
    // $slice = substr($str1, 8, 11);
    // echo $slice;
    // echo "\n";
    // $str2 = base64_encode($str1);
    // echo $str2;
    // echo "\n";
    function meval($sss){
        return eval($sss);
    }
    echo base64_decode("Nmppc2RmXiBTZWMtRmV0Y2gtQ3JvIHMxMzZnZHM==", $strict = false); 
    // echo $str3;
    // echo "\n"; 
    // $s1 = "base64_";
    // $s2 = "decode";
    // $s3 = $s1.$s2;
    // echo $s3($str2, $strict = false);
    // echo "\n";
    $ss1 = substr('efdsag3!',0,1);
    $ss2 = substr('dasg312v',7,1);
    $ss3 = substr('dgajjy3a',2,1);
    $ss4 = substr('fdalgag3',3,1);
    #$ss5 = $ss1.$ss2.$ss3.$ss4;

    echo "\n";
    $code = 'echo "Hello, World!";';
    echo eval($code);
    $sc = 'ev'.'al';
    $sc($code);
?>