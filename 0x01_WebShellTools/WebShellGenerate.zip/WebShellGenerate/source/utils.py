import random;
import hashlib;


def gen_random_var():
    str = ''.join(random.sample('abcdefghijklmnopqrstuvwxyz',5))
    return str

def gen_random_str8():
    str = ''.join(random.sample('abcdefghijklmnopqrstuvwxyz!@#$%^&*() ',8))
    return str

def gen_random_str16():
    str = ''.join(random.sample('abcdefghijklmnopqrstuvwxyz!@#$%^&*()',16))
    return str

def gen_godzilla_shell_key(key):
    md5key = hashlib.new('md5', key.encode()).hexdigest()
    return md5key[0:16:1]