



### reference: https://ansar0047.medium.com/remote-code-execution-unix-and-windows-4ed3367158b3