原版下载地址：
https://portswigger.net/burp/releases/download?product=pro&type=Jar

使用说明：
原版下载后重命名为burpsuite_pro.jar放入当前目录即可。

补丁来源：
https://github.com/x-Ai/BurpSuiteLoader